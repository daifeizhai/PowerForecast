"""PowerForecast research framework."""
