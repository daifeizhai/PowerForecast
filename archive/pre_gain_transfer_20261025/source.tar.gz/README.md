# PowerForecast · SAPF

**选择性自适应功率预测（Selective Adaptive Power Forecasting）研究框架。**

当前主线研究哪些负荷规律可共享、哪些源域值得迁移，以及如何减少未知域上的负迁移。近期实现是基于 Ridge 的 SAPF 机制实验：历史窗口归一化、源域相似性、验证域可靠性与局部历史回退；尚未实现完整深度共享表征架构或跨设施总表精度验收。

当前任务固定为 **24h（96 点）/ 3d（288 点）**，15 分钟采样，过去 **14 天（1344 点）** 输入。7d、HDSF 和旧预测方案转入[归档](archive/pre_sapf_bc6a439/README.md)，不参与默认运行。原始数据、历史预测、模型与缓存均保留。

Google 10 个测试电力域的 SAPF 平均曲线 MAPE 为 **24h 3.0232%、3d 3.2241%**。24h 平均优于原始多源 Ridge，但两任务最差域均更差，3d 平均也未超过 Ridge；当前不能认定已全面改善鲁棒性，完整证据见[Google结果报告](docs/SAPF_RESULTS.md)。

后续已完成 [M100 两机架跨节点实验](docs/M100_RESULTS.md)：33 节点按 12/11/10 划分源/验证/测试，专用 15min 宽表适配将 total_power_avg 从 W 转为 kW；加入归一化、源选择、历史回退及可靠性四项独立关闭实验。SAPF 优于原始 Ridge，但仍未超过前三天同刻均值；这不是跨数据中心泛化验证。

## 1. 运行

Python 3.11+；优先使用已有 .venv，无需升级本机环境。首次安装只需 requirements.txt，其他基础模型的依赖见 requirements-optional.txt。

```powershell
# M100：当前新增的真实节点功率实验，包含四项受控消融；协议与 Google 分开
.\.venv\Scripts\python.exe scripts/run_experiment.py --config configs/sapf_m100.yaml
# 默认真实 Google：独立源域、验证域、测试域，运行 24h / 3d
.\.venv\Scripts\python.exe scripts/run_experiment.py
# 同一入口：合成流程检查、查看已存结果、缩小运行范围
.\.venv\Scripts\python.exe scripts/run_experiment.py --demo
.\.venv\Scripts\python.exe scripts/run_experiment.py --results latest
.\.venv\Scripts\python.exe scripts/run_experiment.py --models seasonal_naive three_day_mean ridge normalized_ridge --horizons 3d
# 完整指标只在需要时打印；默认终端展示配置、进度、平均/最差 MAPE、保存位置
.\.venv\Scripts\python.exe scripts/run_experiment.py --results latest --detailed
.\.venv\Scripts\python.exe -m pytest -q
```

默认配置为 [sapf_google.yaml](configs/sapf_google.yaml)，模型参数与默认清单集中在 [models.yaml](configs/models.yaml)。默认比较：前一天同刻、前三天同刻均值、多源 Ridge、历史窗口归一化 Ridge、相似性选择、SAPF 可靠性选择。另对每个源域保存原始/归一化单源诊断；终端只列出预先固定的首个单源，全部矩阵和指标保存在文件中。

M100 使用独立的 [sapf_m100.yaml](configs/sapf_m100.yaml) 与 [m100_models.yaml](configs/m100_models.yaml)，默认另含四项冻结设置下的单机制关闭实验。两套数据不混合拟合、不混用单位，`--results latest` 按各运行保存的协议与物理目标显示。

latest 只选择完成的真实 SAPF 运行。合成结果只验证程序；旧结果用明确目录查看，不并入新排行榜。

## 2. 实验协议

当前 Google 方案按每个 cell 内自然 PDU 顺序，以位置模 3 分配源域/验证域/测试域。先排除不完整采样、歧义映射、MVPP 结构和此前三个 pilot 目标。最终为 **14 源域 / 11 独立验证域 / 10 测试域**，角色互不重叠；不是同时留出独立设施。

| 项目 | 24h | 3d |
| --- | --- | --- |
| 历史/预测长度 | 1344 / 96 | 1344 / 288 |
| 源开发拟合标签截止 | D18 | D18 |
| 验证域起报 | D18/D19 | D18/D19 |
| 源最终拟合标签截止 | D22 | D22 |
| 测试域起报 | D22—D30 | D22—D28 |
| 最终源训练窗口 | 每域 8 个，共 112 个 | 每域 6 个，共 84 个 |
| 测试起报/曲线点 | 90 / 8640 | 70 / 20160 |

Dk 表示已观测前 k 个 trace 日，预测从 D(k+1) 开始。Google 按官方起点恢复实际时间，日历特征只使用相对日/周相位；目标历史与未来标签不填补，每个 15 分钟区间需 3/3 有效原始点。完整性筛选只用质量掩码，不使用误差；结论受完整观测条件限制。

所有策略、候选网格、源池和阈值在测试前声明。SAPF 只用源域拟合模型，用独立验证域选择候选及估计可靠性；全部任务最终拟合后统一保存冻结文件，再创建测试窗口。滚动推理可使用起报前目标历史，不能重新拟合或用未来标签选源。已看过的历史 Google 发布数据不等于新采集的未触碰数据。

## 3. SAPF 机制与公平对照

1. **归一化：** 每个训练或推理窗口只用过去 14 天目标计算均值和标准差，将目标历史及训练标签转换到局部尺度；预测后恢复原尺度。标准差下界为 max(0.01 × |历史均值|, 1e-6)。目标历史统计不参与全局权重拟合。
2. **相似性：** 从历史计算水平、变异系数、日/周相关、相对趋势与爬坡、日内轮廓波动。特征尺度只由源域拟合，以距离、top-k 和温度加权归一化源专家，参数只由验证域选择。
3. **可靠性选择：** 使用源专家在独立验证域的误差估计可靠性，并按目标历史与源域的距离调整迁移强度；允许回退到固定的前三天同刻均值。验证目标为域平均 MAPE + 0.1 × 最差域 MAPE，候选网格见模型配置。

MAPE、WAPE、RMSE、MAE 仍由唯一公共指标函数计算；MAPE 排除 |标签|≤1e-8 并记录计数。曲线和日均分开计分，跨域平均按域等权。负迁移在相同目标、起报和标签条件下比较固定方法；分别记录原始/归一化增加源域，以及 SAPF 相对归一化多源的变化。3d 窗口可重叠，另存每 3 天起报的非重叠检验。

验证集上用于选参的 SAPF 分数是选择期分数，不能当作无偏泛化成绩。最终结论须同时看测试平均、最差域及负迁移比例，不能只引用较好域或将相关性写成因果。

## 4. 数据边界

| 数据 | 用途与当前状态 |
| --- | --- |
| Google PowerData 2019 | 当前机制研究；功率利用率/电力域，不能改称设施总表 kW |
| Alibaba GPU v2020 | 本地 7 张表的无表头 schema 已适配、官方哈希核对；资源统计无可信功率标签，全生命周期统计不能提前使用 |
| M100 ExaData | 专用 15min 宽表适配和 33 节点冻结实验已完成，目标为 node_power_kw；只代表两个机架内跨节点，保留聚合边界与上报时延的假定 |
| UCC2023 | 两份完整 CSV 已审计，Power 为服务器 W，原生 10min；D2 功率缺失 13.84%，存在夏令时重复钟表时刻；需独立原生/30min 协议 |
| NLR Eagle | 整体保留为最终独立测试域，禁止训练、验证、选参和策略设计；本轮未打开观测或标签 |
| NLR ESIF | 设施五分项 component_sum、kW、UTC 未核实；只作物理契约与旧实验参考，区别于 Eagle |

来源与准入条件集中在 [registry.yaml](configs/datasets/registry.yaml)，详见[多源核验](docs/SAPF_DATA_AUDIT.md)和 [M100/UCC2023 实际文件审计报告](docs/M100_UCC2023_DATA_AUDIT.md)。原始数据审计不改变上一轮 Google 实验结果。

```powershell
# 只核对本地数据，不下载外部大数据
.\.venv\Scripts\python.exe scripts/audit_datasets.py --hashes --output results/analysis/sapf/datasets-recheck.json
# 全量审计本地 M100/UCC 功率、原生采样、缺口、重复和连续长度；目录必须为新路径
.\.venv\Scripts\python.exe scripts/audit_power_sources.py --output results/analysis/power_sources/recheck_01
# 通用预处理必须显式选择配置与新的版本路径；已有产物拒绝覆盖
.\.venv\Scripts\python.exe scripts/prepare_data.py --config configs/datasets/nlr.yaml --output data/processed/nlr_esif_audited_v2.parquet
```

## 5. 架构、产物与复现

| 位置 | 职责 |
| --- | --- |
| scripts/run_experiment.py | 唯一实验与结果入口；显式访问归档 |
| src/data/ | 物理契约、逐域适配、14 天窗口、角色/时间隔离、历史特征 |
| src/data/m100_panel.py | M100 15min 宽表、节点身份、W→kW、缺失掩码、发布槽可用性约束 |
| src/models/ml/normalized.py / sapf.py / ablation.py | 可保存恢复的归一化、选择性机制与冻结设置下的独立消融，预测不接收标签 |
| src/training/experiment.py / lifecycle.py | 源拟合、验证选择、最终拟合、全任务冻结、测试 |
| src/evaluation/ | 公共评分/归档、紧凑输出、配对诊断与独立复算 |
| archive/pre_sapf_bc6a439/ | 旧源码压缩包、逐文件哈希、44 次历史运行索引及产物保护清单 |

每次运行建立独立 results/runs/<UTC>_sapf_<标识>/，保存完整配置、角色、原始来源哈希、源码摘要、开发/最终模型、验证选择、frozen-before-test.json、test-start.json、完整预测、曲线/日均/逐起报指标、源权重、相似性与误差分析、恢复和复算记录。错误运行保留 failed 状态，不标成完成。旧模型、数据和预测不写回。

新增模型须实现 BaseForecaster.fit(WindowBatch) / predict(ForecastInputs)，默认清单、公共评分、冻结/恢复与真实 CLI 一起验证。history=[N,L,C]、future_known=[N,H,K]、targets=[N,H]；目标在历史第 0 列。域身份是侧边元数据，数组按只读使用。未来输入只包含已知日历，不加入未来天气、IT/GPU 或任务事后统计。

```powershell
# 对 SAPF 已存预测复算（output 必须为新路径）
.\.venv\Scripts\python.exe scripts/audit_cross_domain.py --run results/runs/<SAPF运行目录> --output results/analysis/sapf/recheck.json
# 同一入口显式打开冻结的旧 Google/HDSF 流程；这里只显示帮助
.\.venv\Scripts\python.exe scripts/run_experiment.py --legacy-config configs/google_hdsf.yaml --help
# 历史分数按原记录显示，不重训
.\.venv\Scripts\python.exe scripts/run_experiment.py --results results/runs/20261014T191923Z_google_9a3ad6
```

实验设计见 [SAPF_PROTOCOL.md](docs/SAPF_PROTOCOL.md)，本轮真实结果、限制及后续安排见 [SAPF_RESULTS.md](docs/SAPF_RESULTS.md)。完整深度共享表征、多数据集功率监督及 Eagle 最终验证仍属后续工作。
