"""PowerForecast research framework."""
